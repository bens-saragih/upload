from django.http import HttpResponse# untuk yang tidak menggunakan template
from django.shortcuts import render


def index(request):
	context = {
		'judul':'Home',
		'penulis':'bento'



	}



	return render(request,'index.html',context)

def admin(request):
	return render(request,'admin.html')