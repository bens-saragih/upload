

from django.conf.urls import url,include

from . import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    url(r'^$',views.index),
    url(r'^admin/',views.admin),
    url(r'^blog/',include('blog.urls')),


]
