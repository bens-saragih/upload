from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
	context = {
		'judul':'Blog',
		'penulis':'Bento',
		'navigasi':[
			['/','home'],
			['/admin','admin'],
			['about/','about'],

		]



	}

	return render(request,'blog/index.html',context)

def about(request):
	context = {
		'judul':'About',
		'penulis':'Bento',
		'nav':[
			['/','home'],
			['/admin','admin'],
			['blog','blog'],


		]
	}
	return render(request,'blog/about.html',context)

